package koeait.g333.sheveleva.calculatorapi;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
public interface CalculatorService {
    @GET("add")
    Call<String> add(@Query("a") String a, @Query("b") String b);

    @GET("subtract")
    Call<String> subtract(@Query("a") String a, @Query("b") String b);

    @GET("multiply")
    Call<String> multiply(@Query("a") String a, @Query("b") String b);

    @GET("divide")
    Call<String> divide(@Query("a") String a, @Query("b") String b);
}
