package koeait.g333.sheveleva.calculatorapi;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.os.StrictMode;

import java.io.IOException;

import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class MainActivity extends AppCompatActivity {

    private EditText editTextA, editTextB;
    private TextView resultTextView;
    private CalculatorService service;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Отключаем ограничение на сетевые операции в главном потоке (для упрощения)
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);


        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.31.36:1880/calculator/")
                .addConverterFactory(ScalarsConverterFactory.create())
                .build();

        service = retrofit.create(CalculatorService.class);

        // Привязка UI-элементов
        editTextA = findViewById(R.id.editTextA);
        editTextB = findViewById(R.id.editTextB);
        resultTextView = findViewById(R.id.resultTextView);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    // Обработчики нажатий на кнопки (привязываются через android:onClick в XML)
    public void onAddClick(View view) {
        performOperation("add");
    }

    public void onSubtractClick(View view) {
        performOperation("subtract");
    }

    public void onMultiplyClick(View view) {
        performOperation("multiply");
    }

    public void onDivideClick(View view) {
        performOperation("divide");
    }
    private void performOperation(String operation) {
        String aStr = editTextA.getText().toString().trim(); // Убираем пробелы
        String bStr = editTextB.getText().toString().trim();

        if (aStr.isEmpty() || bStr.isEmpty()) {
            resultTextView.setText("Input error: fields are empty");
            return;
        }

        try {

            aStr = aStr.replace(',', '.');
            bStr = bStr.replace(',', '.');

            Call<String> call = null;
            switch (operation) {
                case "add":
                    call = service.add(aStr, bStr);
                    break;
                case "subtract":
                    call = service.subtract(aStr, bStr);
                    break;
                case "multiply":
                    call = service.multiply(aStr, bStr);
                    break;
                case "divide":
                    call = service.divide(aStr, bStr);
                    break;
            }

            if (call != null) {
                try {
                    Response<String> response = call.execute();
                    if (response.isSuccessful() && response.body() != null) {
                        String result = response.body().trim();

                        // Проверяем, является ли ответ ошибкой
                        if (result.contains("error") || result.contains("{")) {
                            resultTextView.setText("Error: " + result);
                        } else {
                            resultTextView.setText("Result: " + result);
                        }
                    } else {
                        resultTextView.setText("API Error: " + response.code());
                    }
                } catch (IOException e) {
                    resultTextView.setText("Network error");
                    e.printStackTrace();
                }
            }

        } catch (NumberFormatException e) {
            resultTextView.setText("Input error: enter valid numbers (e.g. 5.0)");
        } catch (Exception e) {
            resultTextView.setText("Network error");
            e.printStackTrace();
        }
    }
}